pub struct ChatMessage {
    pub sender: String,
    pub message: String,
    pub timestamp: String,
}
