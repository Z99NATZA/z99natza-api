use std::sync::Arc;

use serde::{Deserialize, Serialize};

use crate::app::AppResult;

// ---------------------------------------

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatRequest {
    pub message: String,
    pub sender: String,
    pub chat_id: String,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct Chat {
    pub sender: String,
    pub message: String,
}

#[derive(serde::Serialize)]
pub struct ChatMessage {
    pub message: String,
    pub sender: String,
    pub timestamp: String,
}

#[async_trait::async_trait]
pub trait ChatRepository: Send + Sync {
    async fn load(&self, chat_id: &str) -> AppResult<Vec<Chat>>;
    async fn save(&self, chat_id: &str, history: &[Chat]) -> AppResult<()>;
}

#[async_trait::async_trait]
pub trait ChatAi: Send + Sync {
    async fn chat(&self, context: &str) -> AppResult<String>;
}

pub struct HandleChat {
    repo: Arc<dyn ChatRepository>,
    ai: Arc<dyn ChatAi>,
}

// ---------------------------------------

impl HandleChat {
    pub async fn execute(&self, req: ChatRequest) -> AppResult<Vec<ChatMessage>> {
        let mut history = self.repo.load(&req.chat_id).await?;

        history.push(Chat {
            sender: req.sender.clone(),
            message: req.message.clone(),
        });

        let context = build_context(&history);

        let ai_reply = self.ai.chat(&context).await?;

        history.push(Chat {
            sender: "assistant".into(),
            message: ai_reply.clone(),
        });

        self.repo.save(&req.chat_id, &history).await?;

        Ok(vec![
            ChatMessage::user(req),
            ChatMessage::ai(ai_reply),
        ])
    }
}

fn build_context(history: &[Chat]) -> String {
    history
        .iter()
        .map(|chat| format!("{}: {}", chat.sender, chat.message))
        .collect::<Vec<_>>()
        .join("\n")
}
