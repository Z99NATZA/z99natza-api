use crate::app::AppResult;

pub struct JsonChatRepository {
    base_path: String,
}

impl JsonChatRepository {
    pub fn new(base_path: impl Into<String>) -> Self {
        Self {
            base_path: base_path.into(),
        }
    }

    fn path(&self, chat_id: &str) -> String {
        format!("{}/chat_{}.json", self.base_path, chat_id)
    }
}

#[async_trait::async_trait]
impl ChatRepository for JsonChatRepository {
    async fn load(&self, chat_id: &str) -> AppResult<Vec<Chat>> {
        let path = self.path(chat_id);

        if !tokio::fs::try_exists(&path).await? {
            return Ok(Vec::new());
        }

        let content = tokio::fs::read_to_string(&path).await?;
        let history = serde_json::from_str(&content)?;
        Ok(history)
    }

    async fn save(&self, chat_id: &str, history: &[Chat]) -> AppResult<()> {
        let path = self.path(chat_id);
        let json = serde_json::to_string_pretty(history)?;
        tokio::fs::write(path, json).await?;
        Ok(())
    }
}
