use std::sync::Arc;

use crate::app::AppResult;

pub struct AiManager {
    client: Arc<dyn AiClient>,
}

impl AiManager {
    pub fn new(client: Arc<dyn AiClient>) -> Self {
        Self { client }
    }
}

#[async_trait::async_trait]
impl ChatAi for AiManager {
    async fn chat(&self, context: &str) -> AppResult<String> {
        self.client.send(context).await
    }
}
